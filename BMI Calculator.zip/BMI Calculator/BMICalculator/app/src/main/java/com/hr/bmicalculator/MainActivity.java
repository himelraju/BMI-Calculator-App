package com.hr.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText kg, inch, feet;
    TextView resultdis;
    Button getbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        kg = findViewById(R.id.kg);
        inch = findViewById(R.id.inch);
        feet = findViewById(R.id.feet);
        resultdis = findViewById(R.id.resultdis);
        getbtn = findViewById(R.id.getbtn);


        getbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mykg = kg.getText().toString();

                float mykgs = Float.parseFloat(mykg);

                String myinch = inch.getText().toString();

                float myinchs = Float.parseFloat(myinch);

                String myfeet = feet.getText().toString();

                float myfeets = Float.parseFloat(myfeet);

                float myheight = (float) (myfeets*0.3048 + myinchs*0.0254);

                float myindex = mykgs/myheight/myheight;

                resultdis.setText(""+myindex);



            }
        });


    }
}